python generateInfomaps.py
pause