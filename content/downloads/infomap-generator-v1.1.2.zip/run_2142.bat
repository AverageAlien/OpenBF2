python generateInfomaps_2142.py
pause